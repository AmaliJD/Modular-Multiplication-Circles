﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DrawLines : MonoBehaviour
{
    public Slider slider;
    public Text text, toggletext;
    public Toggle snap;

    public Image fill, handle, toggle;

    public int nodes;
    private int prevNodes;

    public float number;
    private float prevNum, step = 0.0009f;

    public int distance;
    public Material material;

    [SerializeField]
    private Color startColor, endColor;

    public List<LineRenderer> linerenderers;

    void Awake()
    {
        startColor = Color.cyan;
        endColor = Color.blue;
        linerenderers = new List<LineRenderer>();
        prevNodes = nodes;
        prevNum = number;

        for (int i = 0; i < nodes; i++)
        {
            GameObject newObj = new GameObject();
            newObj.AddComponent<LineRenderer>();
            newObj.transform.parent = transform;

            LineRenderer lr = newObj.GetComponent<LineRenderer>();
            lr.material = material;
            linerenderers.Add(lr);
        }

        Draw();
    }

    private void Start()
    {
        //GetComponent<AudioSource>().Play();
    }

    public void changeNodes(int n)
    {
        if(n > prevNodes)
        {
            for (int i = prevNodes; i < n; i++)
            {
                GameObject newObj = new GameObject();
                newObj.AddComponent<LineRenderer>();
                newObj.transform.parent = transform;

                LineRenderer lr = newObj.GetComponent<LineRenderer>();
                lr.material = material;
                linerenderers.Add(lr);
            }
        }
        else if(n < prevNodes)
        {
            int i = 0, end = prevNodes - n;
            foreach (Transform t in transform)
            {
                if (i == end)
                    break;

                linerenderers.RemoveAt(0);
                Destroy(t.gameObject);
                i++;
            }
        }
    }

    public void Draw()
    {
        float stepAngle = 360 / nodes;
        for (int i = 0; i < nodes; i++)
        {
            float value = (number * i) % nodes;
            var start = Quaternion.AngleAxis(i * stepAngle, Vector3.forward);
            var end = Quaternion.AngleAxis(value * stepAngle, Vector3.forward);
            var startPosition = start * Vector3.right * distance;
            var endPosition = end * Vector3.right * distance;
            linerenderers[i].SetPosition(0, startPosition);
            linerenderers[i].SetPosition(1, endPosition);
        }
    }

    // Update is called once per frame
    void Update()
    {
        slider.wholeNumbers = snap.isOn;
        number = slider.value;
        text.text = (Mathf.Round(number * 100) / 100) + "";

        if (prevNodes != nodes)
        {
            changeNodes(nodes);
            Draw();
        }

        if (prevNum != number)
            Draw();

        prevNodes = nodes;
        prevNum = number;

        foreach (LineRenderer lr in linerenderers)
        {
            lr.SetColors(startColor, endColor);
        }

        Color.RGBToHSV(startColor, out float startH, out float startS, out float startV);
        Color.RGBToHSV(endColor, out float endH, out float endS, out float endV);
        endColor = Color.HSVToRGB(endH - .001f, startS, startV);
        startColor = Color.HSVToRGB(endH - .09f, startS, startV);
        Camera.main.backgroundColor = Color.HSVToRGB(endH, endS, .05f);

        fill.color = endColor;
        handle.color = startColor;
        text.color = Color.HSVToRGB(startH, .8f, startV);
        toggletext.color = Color.HSVToRGB(startH, .8f, startV);
        toggle.color = Color.HSVToRGB(startH, .8f, startV);

        /*
        if (number < 361)
            number += step;

        if (number > 361)
            number = 361;

        if (step < 1.1f && number <= 195)
        {
            step *= 1.001f;
        }
        else if (step >= 0.001f && number > 195 && number < 360)
        {
            step *= 0.99885f;
        }
        else if (step >= 0.0005f && number > 360)
        {
            step *= 0.998f;
        }

        if (Input.GetKeyDown("escape"))
        {
            Application.Quit();
        }*/

        if (Input.GetKeyDown("escape"))
        {
            Application.Quit();
        }
    }
}
